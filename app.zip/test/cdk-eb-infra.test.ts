// import { Template } from '@aws-cdk/assertions';
// import * as cdk from '@aws-cdk/core';
// import * as CdkEbInfra from '../lib/cdk-eb-infra-stack';

// example test. To run these tests, uncomment this file along with the
// example resource in lib/cdk-eb-infra-stack.ts
test('SQS Queue Created', () => {
//   const app = new cdk.App();
//     // WHEN
//   const stack = new CdkEbInfra.CdkEbInfraStack(app, 'MyTestStack');
//     // THEN
//   const template = Template.fromStack(stack);

//   template.hasResourceProperties('AWS::SQS::Queue', {
//     VisibilityTimeout: 300
//   });
});
